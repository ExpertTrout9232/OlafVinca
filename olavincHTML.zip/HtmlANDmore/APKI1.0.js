let btn = document.createElement("button");
btn.innerHTML = "Click Me";
document.body.appendChild(btn);
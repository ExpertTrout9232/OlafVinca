1. extract the zip archive
2. install the node js (installer is icluded in zip archive)
3. run with node js